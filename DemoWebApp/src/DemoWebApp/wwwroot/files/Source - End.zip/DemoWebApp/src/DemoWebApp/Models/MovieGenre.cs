﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DemoWebApp.Models
{
    public enum MovieGenre
    {
        Other,
        Action,
        Comedy,
        Crime,
        Documentary,
        Drama,
        Family,
        Horror,
        Love,
        Mystery,
        Thriller
    }
}
